#!/bin/bash

ps h --ppid $1 -o pid